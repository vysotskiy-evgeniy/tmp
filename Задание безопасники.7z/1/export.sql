output D:\export_1.txt;
select * from TABLE_1;
output D:\export_2.txt;
select * from TABLE_2;
exit ;