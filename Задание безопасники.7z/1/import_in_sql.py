d = {}
with open ('D:\export_1.txt') as file:
    ex1 = file.read().split()
ex1 = ex1[4:]
for c in range(0, len(ex1), 2):
    d[int(ex1[c])] = [ex1[c+1]]
with open ('D:\export_2.txt') as file:
    ex2 = file.read().split()
ex2 = ex2[4:]
for c in range(0, len(ex2), 2):
    d[int(ex2[c])].append(ex2[c+1])
with open ('D:\insert.txt', 'a') as outfile:
    for key in d.keys():
        outfile.write('INSERT INTO TABLE_3 (ID, Surname, Name) values ({}, "{}", "{}");\n'.format(key, d[key][1], d[key][0]))
